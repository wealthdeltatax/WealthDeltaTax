---
name: wdt-model
description: >
  Expert knowledge of the Wealth Delta Tax (WDT) Python simulation and output pipeline.
  Use whenever the user asks about the WDT model codebase, its architecture, simulation
  mechanics, parameters, output scripts, or infrastructure modules. Triggers on questions
  about wdt_core.py, rates_model.py, wdt_fmt/md/style/analytics.py, the TOML parameter
  file, any of the output scripts (5_3, 5_4, 5_6, 8_3, 16_2–16_7), Route C simulation,
  the C.1 metric, SSM, TCM, SRR/LRR, start-year sweep, or any request to add, fix, or
  extend a WDT model script. Also trigger when the user mentions tau_0, tau_m, alpha,
  TW_settled, Net_settled, or asks how to run the pipeline. The full reference is in
  WDT_Model_Reference.md — read it for details beyond what this skill covers.
---

# WDT Model Skill

The WDT codebase models a Wealth Delta Tax — a progressive accrual-basis wealth tax
with symmetric refunds and a sovereign wealth fund. All code is Python. The full
reference is `WDT_Model_Reference.md` in the project; read the relevant section
before answering or modifying code. This skill gives you enough orientation to know
which section to read.

---

## Architecture at a glance

```
260812_WDT_Params.toml          ← single source of truth for all parameters
        │
        ▼
  wdt_core.load_params()         ← TOML → unified dict p; derives p['N'] via SSM
        │
        ├── wdt_core.py          ← rate function τ(W), Route C simulation, NPV
        └── rates_model.py       ← SSM, TCM, start-year sweep (73 calendar years)
                │
                ▼
        output scripts (5_3, 5_4, 5_6, 8_3, 16_2–16_7)
                │
        infrastructure modules (no matplotlib dependency on imports)
                ├── wdt_fmt.py       ← number → string formatting
                ├── wdt_md.py        ← markdown tables and MdDoc class
                ├── wdt_style.py     ← matplotlib rcParams, colours, save_fig()
                └── wdt_analytics.py ← C.1 metric, sweep runner, CANON_* constants
```

**Two layers, strictly separate:** `wdt_core.py` and `rates_model.py` have no
matplotlib dependency and no file I/O. Output scripts call both layers.

---

## Standard script pattern

Every output script follows this structure:

```python
from wdt_core import load_params
from wdt_fmt import out_dir, ensure_dir
import wdt_analytics as _A          # note: import as module, not from-import
from wdt_analytics import init

_OUT = out_dir('VAL')               # → OUTPUTS/VAL/

def main():
    p = load_params()
    init(p)                          # populates _A.CANON_* constants
    ensure_dir(_OUT)
    # ... domain logic ...

if __name__ == '__main__':
    main()
```

**Critical wdt_analytics gotcha:** always `import wdt_analytics as _A` and
access constants as `_A.CANON_TAU0`, never `from wdt_analytics import CANON_TAU0`.
The `from X import Y` form captures `None` at import time; `init(p)` sets the
module global but does not update the local binding.

---

## Key parameters (quick reference)

| Parameter | What it is |
|:---|:---|
| `tau_0` | Logistic rate floor at W_min (fraction) |
| `tau_m` | Asymptotic rate ceiling (fraction, never reached) |
| `k` | Steepness of logistic climb (per £m) |
| `W_min` | Entry-point wealth; τ = 0 below this (£m) |
| `p['N']` | **Computed** LRR fill year — not a TOML input |
| `alpha` | Declaration ratio (1.0 = honest, <1 under, >1 over) |
| `srr_ratio` | SRR target multiplier (× avg net annual income) |
| `lrr_years` | LRR target (× prevailing government expenditure) |

`p['N']` is derived from the SSM at `load_params()` time. Changing rate or SWF
parameters changes N automatically — always re-run after parameter changes.

---

## Core simulation functions (wdt_core.py)

| Function | Returns | Notes |
|:---|:---|:---|
| `tau(W_m, p)` | float | Marginal WDT rate at declared wealth W |
| `simulate(V0_m, g_series, alpha, p)` | list of N+1 dicts | Route C holding period |
| `simulate_sell(sim, g_next, p)` | dict | Terminal sell event (alpha drops out) |
| `settle_tw(sell_result, p)` | (TW_settled, net_settle_tax, n_iter) | Post-sale oscillation |
| `run_sim(p, alpha, beta, N, g)` | dict | Constant-g convenience runner |
| `run_sim_hist(p, alpha, N)` | dict | Uses `p['returns']` series |
| `decompose_tw_advantage(p, alpha, g)` | dict | C.11 additive decomposition |
| `npv_tax_advantage(p, alpha, g, rho)` | dict | C.12 NPV-adjusted metric |

**Primary output metrics:** `TW_settled` and `Net_settled` (post-sale correction
applied). The naive `TW` field is retained for backward compatibility only.

**Rate function formula** (the docstring in rates_model.py has a known error —
implementation in wdt_core.tau() is correct):
```
τ(W) = τ_m / (1 + ((τ_m − τ_0) / τ_0) × exp(−k × (W − W_min)))
τ(W) = 0  if W < W_min
```

---

## Key analytical metrics (wdt_analytics.py)

```python
import wdt_analytics as _A

# After init(p):
p_minimal = _A.make_p(tau_0=0.10)    # 7-key dict, unspecified → CANON_* defaults
r = _A.run_sim_p(p, alpha=1.2, g=0.10)   # LRU-cached run_sim
c1_val = _A.c1(p, alpha=0.5, g=0.10)     # (Net(α) − Net(1)) / TW(α)
mat = _A.c1_matrix(p)                      # [α × g] in pp
nc = _A.n_crossing(p, alpha=2.0)           # interpolated crossing N
lo, hi = _A.tolerant_zone_bounds(p)        # |C.1| < 2pp band
```

**C.1 sign convention:** positive = understater pays MORE than honest; negative =
overstater pays LESS. The α = 1.0 row is always exactly zero by construction.

---

## Output scripts and what they produce

| Script | Outputs |
|:---|:---|
| `5_3` | `OUTPUTS/VAL/VAL_AppC_Full_Tables.md` — C.1–C.12 tables |
| `5_4` | `OUTPUTS/VAL/VAL_Worked_Examples_Figures.md` — §J–§N examples |
| `5_6` | `OUTPUTS/VAL/` — 10 VAL PNGs (Figs 01–10) |
| `8_3` | `OUTPUTS/RATES/` — markdown report + 9 PNGs |
| `16_2` | `OUTPUTS/VAL_S/` — 12 rate-sweep PNGs |
| `16_3` | `OUTPUTS/VAL_S/` — 6 horizon/wealth PNGs |
| `16_4` | `OUTPUTS/VAL_S/` — 3 interaction surface PNGs |
| `16_5` | `OUTPUTS/VAL_S/VAL_S_Appendix_Tables.md` |
| `16_6` | `OUTPUTS/RATES_S/RATES_S_Appendix_Tables.md` |
| `16_7` | `OUTPUTS/RATES_S/` — 8 sensitivity PNGs |

Run the full pipeline with `run_all.bat` (Windows) or execute scripts individually.
Scripts are independent — no inter-script dependencies.

---

## Infrastructure modules (quick reference)

**wdt_fmt.py** — all formatting, no side effects:
- `fmt_pct(v, dp=2)` — fraction → "12.34%"; `None` → "—"
- `fmt_gbp_m(v, dp=3)` — "£12.345m"
- `fmt_f(v, spec='.1f')` — generic float
- `out_dir('VAL')` → `OUTPUTS/VAL/` (Path); `ensure_dir(path)` → mkdir -p

**wdt_md.py** — markdown assembly:
- `md_table(headers, rows, col_fmt=None, fmt_fn=None)` → str
- `pct_table(row_keys, col_labels, data, row_label)` → list[str]  (VAL.A §C style)
- `MdDoc()` — accumulate lines, `.render()`, `.write(path)`

**wdt_style.py** — matplotlib:
- `apply_style(grid=True)` — call at the top of every figure function
- `apply_style_nogrid()` — for heatmaps/imshow
- `save_fig(fig, path, dpi=300)` — saves, closes, prints path
- Colour constants: `C_UNDER`, `C_HONEST`, `C_OVER`, `C_SSM`, `C_TCM`, `C_LRR`, etc.
- Figure sizes: `FIG_SINGLE (9,5.5)`, `FIG_PAIR (14,5.5)`, `FIG_QUAD (14,9)`, etc.

---

## Common tasks

**Adding a new figure to an output script:**
1. Write a `fig_xxx(p)` function; call `apply_style()` first
2. Use colour constants from `wdt_style`, not inline hex
3. End with `save_fig(fig, _OUT / 'filename.png')`
4. If it's a VAL.S figure (16_x), add an entry to `FIGURE_REGISTRY` in `16_5`

**Adding a new analytical metric:**
1. Add function to `wdt_analytics.py`
2. Add test to `test_wdt_analytics.py`
3. Import in the relevant output script

**Adding a TOML parameter:**
1. Add to TOML with a comment
2. Parse in `wdt_core.load_params()`
3. If it affects the sweep, add to `p['sweep']` and expose via `wdt_analytics.init()`
4. If it affects N, re-run everything and update `snapshot_N`

**Running the tests:**
```bash
python test_wdt_fmt.py
python test_wdt_md.py
python test_wdt_style.py
python test_wdt_analytics.py
```

---

## Known issues (don't repeat these mistakes)

- **rates_model.py docstring**: writes `(1−τ_0)/τ_0` — wrong. Implementation in
  `wdt_core.tau()` correctly uses `(τ_m − τ_0)/τ_0`.
- **beta formula**: additive `g_eff = g + β ln(α)`, not multiplicative. VAL.A §B.3
  documents it incorrectly.
- **from-import of CANON_* constants**: always use `_A.CANON_TAU0`, never
  `from wdt_analytics import CANON_TAU0` (captures `None` at import time).
- **TW vs TW_settled**: always use `TW_settled` and `Net_settled` for analysis;
  `TW` is kept only for backward compatibility.
- **All monetary values in £m** in `wdt_core`; `rates_model` uses £b for aggregates.
- **p['N'] is computed**: it shifts when rate/SWF parameters change. Don't hardcode it.
- **FIGURE_REGISTRY in 16_5**: manually maintained — must be kept in sync when adding
  or renaming VAL.S figures.

---

## Where to read more

Full details on every section are in `WDT_Model_Reference.md` (project root):

| Section | Topic |
|:---|:---|
| §2 | Parameter system and TOML structure |
| §3 | Rate function τ(W) |
| §4 | Route C simulation step-by-step |
| §5 | C.1 metric, tolerant zone, N-crossing, C.11 decomposition |
| §6 | SSM (Sovereign Wealth Fund Solvency Model) |
| §7 | TCM (Taxpayer Cohort Model) and window alignment |
| §8 | Start-year sweep across 73 calendar years |
| §9 | Infrastructure modules (fmt, md, style, analytics) |
| §10 | Output script inventory |
| §11 | Known issues and conventions |
| §12 | Step-by-step extension guides |
